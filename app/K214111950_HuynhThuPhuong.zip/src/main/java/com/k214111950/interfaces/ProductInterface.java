package com.k214111950.interfaces;

import com.k214111950.model.Product;

public interface ProductInterface {
    public void replaceFragment(Product p);

}
