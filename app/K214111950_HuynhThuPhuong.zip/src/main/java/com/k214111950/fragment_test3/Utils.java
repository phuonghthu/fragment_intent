package com.k214111950.fragment_test3;

public class Utils {
    public static final String SELECTED_PRODUCT = "selected_product";

}
